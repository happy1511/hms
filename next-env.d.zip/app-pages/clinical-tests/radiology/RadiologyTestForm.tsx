import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CustomLayout from "@/components/common/CustomLayout";
import { Form } from "@/components/ui/form";
import FormField from "@/components/form-inputs/FormField";
import { RadiologySection, Status } from "@/generated/prisma/enums";
import CustomButton from "@/components/common/CustomButton";
import { RadiologyTest } from "@/generated/prisma/client";
import {
  radiologyTestValidator,
  RadiologyTestValidatorType,
} from "@/validators/api/masters/radiologyTest";
import {
  useCreateRadiologyTest,
  useUpdateRadiologyTest,
} from "@/hooks/query/radiology";

interface Props {
  trigger: React.ReactNode;
  data?: RadiologyTest;
}

const RadiologyTestForm = ({ trigger, data }: Props) => {
  const { mutateAsync: create, isPending: creating } = useCreateRadiologyTest();
  const { mutateAsync: update, isPending: updating } = useUpdateRadiologyTest();

  const form = useForm<RadiologyTestValidatorType>({
    defaultValues: {
      alias: data?.alias || "",
      name: data?.name || "",
      price: data?.price || 0,
      section: data?.section,
      status: data?.status || Status["active"],
    },
    resolver: zodResolver(radiologyTestValidator),
  });

  const handleSubmit = (values: RadiologyTestValidatorType) => {
    if (data) {
      update({ ...values, testId: data.id });
    } else {
      create(values);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent
        showCloseButton={false}
        className="max-w-4xl! border-secondary border-4 bg-white p-0 gap-0"
      >
        <DialogHeader>
          <DialogTitle className="sr-only"></DialogTitle>
          <DialogDescription className="sr-only">
            This action cannot be undone. This will permanently delete your
            account and remove your data from our servers.
          </DialogDescription>
        </DialogHeader>
        <CustomLayout
          title={data ? "Edit Radiology Test" : "Create Radiology Test"}
        >
          <Form {...form}>
            <form
              className="grid grid-cols-2 space-x-2"
              onSubmit={form.handleSubmit(handleSubmit)}
            >
              <FormField
                label="Name"
                type="text"
                control={form.control}
                name="name"
                placeholder="Enter Name"
                required
              />
              <FormField
                label="Alias"
                type="text"
                control={form.control}
                placeholder="Enter Alias"
                name="alias"
                required
              />
              <FormField
                label="Section"
                type="select"
                control={form.control}
                name="section"
                options={Object.values(RadiologySection).map((s) => ({
                  value: s,
                  label: s,
                }))}
                required
              />

              <FormField
                label="Rate"
                type="number"
                control={form.control}
                name="price"
                required
              />

              <div className="col-span-2">
                <CustomButton disabled={creating || updating} type="submit">
                  {data ? "Update" : "Create"}
                </CustomButton>
              </div>
            </form>
          </Form>
        </CustomLayout>
      </DialogContent>
    </Dialog>
  );
};

export default RadiologyTestForm;
