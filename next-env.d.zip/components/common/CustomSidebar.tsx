"use client";

import { ForwardRefExoticComponent, RefAttributes, useState } from "react";
import {
  LayoutDashboard,
  Users,
  UserPlus,
  Calendar,
  UserCircle,
  FileText,
  BedDouble,
  UserCheck,
  DollarSign,
  ChevronDown,
  Stethoscope,
  User,
  Bolt,
  Building2,
  AlertTriangle,
  LucideProps,
  Layers,
  DoorClosed,
  TestTubes,
  FolderOpen,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn, hasModulePermission } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useProfile } from "@/hooks/query/auth";
import { ActionType, ModuleType } from "@/generated/prisma/enums";
import PatientSearchModal from "../patient/PatientSearchModal";
import BedAvailabilityModal from "../bed/BedAvailabilityModal";
import { OPDType } from "@/lib/type";

interface SidebarItem {
  title: string;
  url: string;
  icon: ForwardRefExoticComponent<
    Omit<LucideProps, "ref"> & RefAttributes<SVGSVGElement>
  >;
  module: ModuleType[];
  requireViewPermission?: boolean;
}

const CERTIFICATES_MODULE = "CERTIFICATES" as ModuleType;
const PHARMACY_REPORTS_MODULE = "PHARMACY_REPORTS" as ModuleType;
const PHARMACY_REPORT_COUNTER_SALE_MODULE =
  "PHARMACY_REPORT_COUNTER_SALE" as ModuleType;
const PHARMACY_REPORT_IPD_SALE_MODULE =
  "PHARMACY_REPORT_IPD_SALE" as ModuleType;
const PHARMACY_REPORT_PO_MODULE = "PHARMACY_REPORT_PO" as ModuleType;
const PHARMACY_REPORT_GRN_MODULE = "PHARMACY_REPORT_GRN" as ModuleType;
const PHARMACY_REPORT_STOCK_MODULE = "PHARMACY_REPORT_STOCK" as ModuleType;
const PHARMACY_IPD_ISSUE_MODULE = "PHARMACY_IPD_ISSUE" as ModuleType;
const PHARMACY_IPD_RETURN_MODULE = "PHARMACY_IPD_RETURN" as ModuleType;
const PHARMACY_IPD_BILL_MODULE = "PHARMACY_IPD_BILL" as ModuleType;

const opdItems: SidebarItem[] = [
  {
    title: "PATIENTS OPD",
    url: "/opd/patients",
    icon: Users,
    module: [ModuleType.OPD_BILL],
  },
  {
    title: "WALK-IN QUEUE",
    url: "/opd/walk-in",
    icon: UserPlus,
    module: [ModuleType.OPD_BILL],
  },
  {
    title: "APPOINTMENTS",
    url: "/opd/appointments",
    icon: Calendar,
    module: [ModuleType.APPOINTMENT],
  },
  {
    title: "CERTIFICATES",
    url: "/certificates",
    icon: FileText,
    module: [CERTIFICATES_MODULE],
  },
  // {
  //   title: "SCANNED REPORTS",
  //   url: "/opd/reports",
  //   icon: FileText,
  //   module: [ModuleType.APPOINTMENT],
  // },
  // { title: "PATIENT DOCUMENTS", url: "/patient/documents", icon: FolderOpen },
];

const ipdItems = [
  {
    title: "PATIENTS IPD",
    url: "/ipd/patients",
    icon: Users,
    module: [ModuleType.IPD_BILL],
  },
  {
    title: "DAY CARE",
    url: "/ipd/daycare",
    icon: Users,
    module: [ModuleType.DAY_CARE_IPD],
  },
  {
    title: "MLC PATIENTS",
    url: "/ipd/mlc",
    icon: AlertTriangle,
    module: [ModuleType.IPD_MLC],
  },
  {
    title: "DISCHARGED PATIENTS",
    url: "/ipd/discharged",
    icon: UserCheck,
    module: [ModuleType.DISCHARGE_PATIENT],
  },
  // { title: "PATIENT DOCUMENTS", url: "/ipd/documents", icon: FolderOpen },
];

const patientCareItem: SidebarItem = {
  title: "PATIENT CARE",
  url: "/patient/care-overview",
  icon: Stethoscope,
  module: [
    ModuleType.OPD_BILL,
    ModuleType.IPD_BILL,
    ModuleType.DAY_CARE_IPD,
  ],
  requireViewPermission: true,
};

const patientDocumentsItem: SidebarItem = {
  title: "PATIENT DOCUMENTS",
  url: "/patient/documents",
  icon: FolderOpen,
  module: [
    ModuleType.PATIENT_MASTER,
    ModuleType.OPD_BILL,
    ModuleType.IPD_BILL,
    ModuleType.DAY_CARE_IPD,
    ModuleType.DISCHARGE_PATIENT,
  ],
  requireViewPermission: true,
};

const canAccessSidebarItem = (data: any, item: SidebarItem) => {
  if (!item.requireViewPermission) {
    return hasModulePermission(data, item.module);
  }

  const modules = Array.isArray(item.module) ? item.module : [item.module];
  const permissionMap: Partial<Record<ModuleType, ActionType[]>> =
    data.permissions.reduce(
      (acc: Partial<Record<ModuleType, ActionType[]>>, permission: any) => {
        acc[permission.module.name as ModuleType] = permission.actions.map(
          (action: any) => action.name,
        );
        return acc;
      },
      {} as Partial<Record<ModuleType, ActionType[]>>,
    ) ?? {};

  return modules.some((module) =>
    permissionMap[module]?.includes(ActionType.VIEW),
  );
};

const pharmacyItems = [
  {
    title: "PO",
    url: "/pharmacy/purchase-order",
    icon: Users,
    module: [ModuleType.PHARMACY_PURCHASE_ORDER],
  },
  {
    title: "GRN",
    url: "/pharmacy/grn",
    icon: Users,
    module: [ModuleType.PHARMACY_GRN],
  },
  {
    title: "CHALLAN",
    url: "/pharmacy/challan",
    icon: Users,
    module: [ModuleType.PHARMACY_CHALLAN],
  },
  {
    title: "INVENTORY",
    url: "/pharmacy/inventory",
    icon: Users,
    module: ["PHARMACY_INVENTORY" as ModuleType],
  },
  {
    title: "SALE BILL",
    url: "/pharmacy/sale-bill",
    icon: Users,
    module: [ModuleType.PHARMACY_SALE_BILL],
  },
  {
    title: "SALE RETURN",
    url: "/pharmacy/sale-return/select",
    icon: Users,
    module: [ModuleType.PHARMACY_SALE_RETURN],
  },
  {
    title: "SUPPLIER RETURN",
    url: "/pharmacy/supplier-return",
    icon: Users,
    module: [ModuleType.PHARMACY_SUPPLIER_RETURN],
  },
  {
    title: "SUPPLIER PAYMENT",
    url: "/pharmacy/supplier-payment",
    icon: Users,
    module: [ModuleType.PHARMACY_SUPPLIER_PAYMENT],
  },
  {
    title: "SUPPLIER CREDIT NOTE",
    url: "/pharmacy/supplier-credit-note",
    icon: Users,
    module: [ModuleType.PHARMACY_SUPPLIER_CREDIT_NOTE],
  },
  {
    title: "SUPPLIER LEDGER",
    url: "/pharmacy/supplier-ledger",
    icon: Users,
    module: [ModuleType.PHARMACY_SUPPLIER_LEDGER],
  },
  {
    title: "CUSTOMER LEDGER",
    url: "/pharmacy/customer-ledger",
    icon: Users,
    module: [ModuleType.PHARMACY_CUSTOMER_LEDGER],
  },
  {
    title: "STOCK CORRECTION",
    url: "/pharmacy/form/stock-correction",
    icon: Users,
    module: [ModuleType.PHARMACY_STOCK_CORRECTION],
  },
  {
    title: "REPORTS",
    url: "/pharmacy/reports",
    icon: FileText,
    module: [
      PHARMACY_REPORT_COUNTER_SALE_MODULE,
      PHARMACY_REPORT_IPD_SALE_MODULE,
      PHARMACY_REPORT_PO_MODULE,
      PHARMACY_REPORT_GRN_MODULE,
      PHARMACY_REPORT_STOCK_MODULE,
    ],
  },
  {
    title: "IPD ISSUES",
    url: "/pharmacy/ipd-issue",
    icon: Users,
    module: [PHARMACY_IPD_ISSUE_MODULE],
  },
  {
    title: "IPD RETURNS",
    url: "/pharmacy/ipd-return",
    icon: Users,
    module: [PHARMACY_IPD_RETURN_MODULE],
  },
  {
    title: "IPD BILLS",
    url: "/pharmacy/ipd-bill",
    icon: FileText,
    module: [PHARMACY_IPD_BILL_MODULE],
  },
];

const financeItems: SidebarItem[] = [
  {
    title: "BILLING",
    url: "/finance/billing",
    icon: FileText,
    module: ["FINANCE_BILLING" as ModuleType],
  },
  {
    title: "PAYMENTS",
    url: "/finance/payments",
    icon: DollarSign,
    module: ["FINANCE_PAYMENTS" as ModuleType],
  },
  {
    title: "CATEGORIES",
    url: "/finance/categories",
    icon: DollarSign,
    module: [ModuleType.FINANCE_CATEGORY_MASTER],
  },
  {
    title: "INCOME",
    url: "/finance/income",
    icon: DollarSign,
    module: [ModuleType.INCOME],
  },
  {
    title: "EXPENSE",
    url: "/finance/expense",
    icon: DollarSign,
    module: [ModuleType.EXPENSE],
  },
];

const masters: SidebarItem[] = [
  {
    title: "DOCTORS",
    url: "/doctors",
    icon: Stethoscope,
    module: [ModuleType.DOCTOR_MASTER],
  },
  {
    title: "USERS",
    url: "/users",
    icon: User,
    module: [ModuleType.USER],
  },
  {
    title: "DEPARTMENTS",
    url: "/departments",
    icon: Layers,
    module: [ModuleType.DEPARTMENT_MASTER],
  },
  {
    title: "ROOM TYPE",
    url: "/room-types",
    icon: DoorClosed,
    module: [ModuleType.ROOM_TYPE_MASTER],
  },
  {
    title: "ROOMS",
    url: "/room",
    icon: BedDouble,
    module: [ModuleType.ROOM_MASTER],
  },
  {
    title: "BEDS",
    url: "/beds",
    icon: BedDouble,
    module: [ModuleType.BED_MASTER],
  },
  {
    title: "LOCATIONS",
    url: "/locations",
    icon: BedDouble,
    module: [ModuleType.LOCATION_MASTER],
  },
  {
    title: "COMPANY DETAILS",
    url: "/company",
    icon: Building2,
    module: [
      ModuleType.HOSPITAL_COMPANY_DETAILS,
      ModuleType.LAB_COMPANY_DETAILS,
      ModuleType.PHARMACY_COMPANY_DETAILS,
    ],
  },
];

const billingMasters: SidebarItem[] = [
  {
    title: "BILLING SECTIONS",
    url: "/billing-sections",
    icon: Bolt,
    module: [ModuleType.BILLING_SECTION_MASTER],
  },
  {
    title: "SERVICES",
    url: "/services",
    icon: Bolt,
    module: [ModuleType.SERVICE_MASTER],
  },
];

const pharmacyMasters: SidebarItem[] = [
  {
    title: "HSN/SAC",
    url: "/hsn-sac",
    icon: Bolt,
    module: [ModuleType.PHARMACY_HSN_SAC_MASTER],
  },
  {
    title: "DRUG CATEGORY",
    url: "/drug-category",
    icon: Bolt,
    module: [ModuleType.PHARMACY_DRUG_CATEGORY_MASTER],
  },
  {
    title: "DRUG SUPPLIER",
    url: "/drug-supplier",
    icon: Bolt,
    module: [ModuleType.PHARMACY_SUPPLIER],
  },
  {
    title: "DRUG",
    url: "/drug",
    icon: Bolt,
    module: [ModuleType.PHARMACY_DRUG_MASTER],
  },
];

const labMasters: SidebarItem[] = [
  {
    title: "RADIOLOGY TEMPLATES",
    url: "/clinical-tests/radiology-template/new",
    icon: TestTubes,
    module: ["RADIOLOGY_TEMPLATE_MASTER" as ModuleType],
  },
  {
    title: "CLINICAL TESTS",
    url: "/clinical-tests",
    icon: TestTubes,
    module: [
      ModuleType.PATHOLOGY_TEST_MASTER,
      ModuleType.RADIOLOGY_TEST_MASTER,
    ],
  },
];

const pathologyOrders: SidebarItem[] = [
  {
    title: "CLAIMED",
    url: "/pathology/claimed",
    icon: TestTubes,
    module: [ModuleType.PATHOLOGY_ORDER],
  },
  {
    title: "COMPLETED",
    url: "/pathology/completed",
    icon: TestTubes,
    module: [ModuleType.PATHOLOGY_ORDER],
  },
  {
    title: "CANCELLED",
    url: "/pathology/cancelled",
    icon: TestTubes,
    module: [ModuleType.PATHOLOGY_ORDER],
  },
  {
    title: "OUTSOURCED",
    url: "/pathology/outsourced",
    icon: TestTubes,
    module: [ModuleType.PATHOLOGY_ORDER],
  },
];

const radiologyOrders: SidebarItem[] = [
  {
    title: "CLAIMED",
    url: "/radiology/claimed",
    icon: TestTubes,
    module: [ModuleType.RADIOLOGY_ORDER],
  },
  {
    title: "COMPLETED",
    url: "/radiology/completed",
    icon: TestTubes,
    module: [ModuleType.RADIOLOGY_ORDER],
  },
  {
    title: "CANCELLED",
    url: "/radiology/cancelled",
    icon: TestTubes,
    module: [ModuleType.RADIOLOGY_ORDER],
  },
  {
    title: "OUTSOURCED",
    url: "/radiology/outsourced",
    icon: TestTubes,
    module: [ModuleType.RADIOLOGY_ORDER],
  },
];

export function CustomSidebar() {
  const [opdOpen, setOpdOpen] = useState(true);
  const [ipdOpen, setIpdOpen] = useState(true);
  const [pharmacyOpen, setPharmacyOpen] = useState(false);
  const [financeOpen, setFinanceOpen] = useState(false);
  const [masterOpen, setMasterOpen] = useState(false);
  const [billingMasterOpen, setBillingMasterOpen] = useState(false);
  const [pharmacyMasterOpen, setPharmacyMasterOpen] = useState(false);
  const [labMasterOpen, setLabMasterOpen] = useState(false);
  const [radiologyOrderOpen, setRadiologyOrderOpen] = useState(false);
  const [pathologyOrderOpen, setPathologyOrderOpen] = useState(false);
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;
  const { data } = useProfile(false);

  if (!data) {
    return <div />;
  }

  const visibleMasters = masters.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visibleBillingMasters = billingMasters.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visibleLabMasters = labMasters.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const canViewPatientCare = canAccessSidebarItem(data.data, patientCareItem);
  const canViewPatientDocuments = canAccessSidebarItem(
    data.data,
    patientDocumentsItem,
  );
  const visibleOpd = opdItems.filter((item) =>
    canAccessSidebarItem(data.data, item),
  );
  const visibleIpd = ipdItems.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visiblePharmacy = pharmacyItems.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visiblePathologyOrders = pathologyOrders.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visibleRadiologyOrders = radiologyOrders.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visiblePharmacyMaster = pharmacyMasters.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const visibleFinance = financeItems.filter((item) =>
    hasModulePermission(data.data, item.module),
  );
  const canViewDashboard = hasModulePermission(data.data, [
    ModuleType.HOSPITAL_DASHBOARD,
    ModuleType.PHARMACY_DASHBOARD,
    ModuleType.LAB_DASHBOARD,
  ]);
  const canUsePatientSearch = hasModulePermission(data.data, [
    ModuleType.OPD_BILL,
    ModuleType.IPD_BILL,
    ModuleType.PATIENT_MASTER,
  ]);
  const canViewBedAvailability = hasModulePermission(data.data, [
    ModuleType.BED_MASTER,
  ]);

  const showOpdSection = visibleOpd.length > 0 || canUsePatientSearch;
  const showIpdSection = visibleIpd.length > 0 || canViewBedAvailability;
  const showPharmacySection = visiblePharmacy.length > 0;
  const showFinanceSection = visibleFinance.length > 0;
  const showLabMasterSection = visibleLabMasters.length > 0;
  const showPathologyOrdersSection = visiblePathologyOrders.length > 0;
  const showRadiologyOrdersSection = visibleRadiologyOrders.length > 0;
  const showBillingMastersSection = visibleBillingMasters.length > 0;
  const showPharmacyMastersSection = visiblePharmacyMaster.length > 0;
  const showMastersSection = visibleMasters.length > 0;

  return (
    <Sidebar className="border-r border-sidebar-border top-12 h-[calc(100dvh-48px)] px-2 py-2 bg-sidebar text-tiny!">
      <SidebarHeader className="p-0">
        {/* Dashboard Item */}
        {canViewDashboard && (
          <Link href="/">
            <div
              className={cn(
                "flex text-tiny! items-center gap-3 px-4 py-1.5 h-auto font-semibold data-[active=true]:text-white hover:text-white transition-colors",
                isActive("/")
                  ? "bg-primary text-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent",
              )}
            >
              <LayoutDashboard className="size-3" />
              <span>DASHBOARD</span>
            </div>
          </Link>
        )}
      </SidebarHeader>

      <SidebarContent className="px-0 bg-primary/10">
        {canViewPatientCare && (
          <SidebarGroup className="p-0">
            <SidebarGroupContent>
              <SidebarMenu className="gap-0">
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(patientCareItem.url)}
                    className="px-4 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-sidebar-foreground"
                  >
                    <Link href={patientCareItem.url}>
                      <patientCareItem.icon />
                      <span>{patientCareItem.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {canViewPatientDocuments && (
          <SidebarGroup className="p-0">
            <SidebarGroupContent>
              <SidebarMenu className="gap-0">
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(patientDocumentsItem.url)}
                    className="px-4 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-sidebar-foreground"
                  >
                    <Link href={patientDocumentsItem.url}>
                      <patientDocumentsItem.icon />
                      <span>{patientDocumentsItem.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* OPD Section */}
        {showOpdSection && (
          <Collapsible open={opdOpen} onOpenChange={setOpdOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny! ">
                  <div className="flex items-center gap-3">
                    <Users className="size-3" />
                    <span>OPD</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      opdOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleOpd.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                    {canUsePatientSearch && (
                      <PatientSearchModal
                        trigger={
                          <SidebarMenuItem>
                            <SidebarMenuButton
                              asChild
                              className="pl-8 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black"
                            >
                              <div>
                                <UserCircle />
                                <span>PATIENT PROFILE</span>
                              </div>
                            </SidebarMenuButton>
                          </SidebarMenuItem>
                        }
                        actions={(row) => (
                          <Link
                            className="text-secondary hover:underline text-tiny"
                            href={`/invoice/${(row as OPDType).invoice.id}`}
                          >
                            Select
                          </Link>
                        )}
                      />
                    )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* IPD Section */}
        {showIpdSection && (
          <Collapsible open={ipdOpen} onOpenChange={setIpdOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <BedDouble className="size-3" />
                    <span>IPD</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      ipdOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleIpd.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                    {canViewBedAvailability && (
                      <SidebarMenuItem>
                        <BedAvailabilityModal />
                      </SidebarMenuItem>
                    )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Pharmacy Section */}
        {showPharmacySection && (
          <Collapsible open={pharmacyOpen} onOpenChange={setPharmacyOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <BedDouble className="size-3" />
                    <span>PHARMACY</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      pharmacyOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visiblePharmacy.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny! [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Finance Section */}
        {showFinanceSection && (
          <Collapsible open={financeOpen} onOpenChange={setFinanceOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <DollarSign className="size-3" />
                    <span>FINANCE</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      financeOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleFinance.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {showLabMasterSection && (
          <Collapsible open={labMasterOpen} onOpenChange={setLabMasterOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>LAB MASTER</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      labMasterOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleLabMasters.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {showPathologyOrdersSection && (
          <Collapsible
            open={pathologyOrderOpen}
            onOpenChange={setPathologyOrderOpen}
          >
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>PATHOLOGY ORDER</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      pathologyOrderOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visiblePathologyOrders.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {showRadiologyOrdersSection && (
          <Collapsible
            open={radiologyOrderOpen}
            onOpenChange={setRadiologyOrderOpen}
          >
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>RADIOLOGY ORDER</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      radiologyOrderOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleRadiologyOrders.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Master Section */}
        {showBillingMastersSection && (
          <Collapsible
            open={billingMasterOpen}
            onOpenChange={setBillingMasterOpen}
          >
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>BILLING</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      billingMasterOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleBillingMasters.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Pharmacy Master Section */}
        {showPharmacyMastersSection && (
          <Collapsible
            open={pharmacyMasterOpen}
            onOpenChange={setPharmacyMasterOpen}
          >
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>PHARMACY MASTERS</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      pharmacyMasterOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visiblePharmacyMaster.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Master Section */}
        {showMastersSection && (
          <Collapsible open={masterOpen} onOpenChange={setMasterOpen}>
            <SidebarGroup className="p-0">
              <CollapsibleTrigger className="w-full bg-transparent">
                <SidebarGroupLabel className="flex items-center justify-between px-4 py-1.5 h-auto text-sidebar-foreground hover:bg-sidebar-accent cursor-pointer font-semibold data-[active=true]:text-white hover:text-white text-tiny!">
                  <div className="flex items-center gap-3">
                    <Bolt className="size-3" />
                    <span>MASTERS</span>
                  </div>
                  <ChevronDown
                    className={cn(
                      "size-3 transition-transform duration-200",
                      masterOpen ? "rotate-180" : "",
                    )}
                  />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent className="bg-background">
                <SidebarGroupContent>
                  <SidebarMenu className="gap-0">
                    {visibleMasters.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive(item.url)}
                          className="pl-8 py-1.5 h-auto text-tiny!   [&>svg]:size-3 font-semibold data-[active=true]:text-white hover:text-white text-black hover:text0white"
                        >
                          <Link href={item.url}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
