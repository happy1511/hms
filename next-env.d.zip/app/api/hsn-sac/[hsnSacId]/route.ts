import {
  deleteAPI,
  getDetailsAPI,
  updateAPI,
} from "@/controllers/hsn-sac/hsnSac";
import { ActionType, ModuleType } from "@/generated/prisma/enums";
import { withErrorHandling } from "@/lib/errorHandler";
import { checkPermission } from "@/middlewares/auth/checkUserPermissions";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ hsnSacId: string }> },
) {
  const p = await params;
  return withErrorHandling(() =>
    checkPermission(
      request,
      [
        {
          module: ModuleType.PHARMACY_HSN_SAC_MASTER,
          action: ActionType.VIEW,
        },
      ],
      () => getDetailsAPI(request, { params: p }),
    ),
  );
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ hsnSacId: string }> },
) {
  const p = await params;
  return withErrorHandling(() =>
    checkPermission(
      request,
      [
        {
          module: ModuleType.PHARMACY_HSN_SAC_MASTER,
          action: ActionType.UPDATE,
        },
      ],
      (req, user) => updateAPI(req, { params: p }, user),
    ),
  );
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ hsnSacId: string }> },
) {
  const p = await params;
  return withErrorHandling(() =>
    checkPermission(
      request,
      [
        {
          module: ModuleType.PHARMACY_HSN_SAC_MASTER,
          action: ActionType.DELETE,
        },
      ],
      (req, user) => deleteAPI(req, { params: p }, user),
    ),
  );
}
