import { createAPI, deleteAPI, getAPI } from "@/controllers/opd/opd";
import { ActionType, ModuleType } from "@/generated/prisma/enums";
import { withErrorHandling } from "@/lib/errorHandler";
import { checkPermission } from "@/middlewares/auth/checkUserPermissions";

export async function GET(request: Request) {
  return withErrorHandling(() =>
    checkPermission(
      request,
      [{ module: ModuleType["OPD_BILL"], action: ActionType["VIEW"] }],
      () => getAPI(request),
    ),
  );
}

export async function POST(request: Request) {
  return withErrorHandling(() =>
    checkPermission(
      request,
      [{ module: ModuleType["OPD_BILL"], action: ActionType["CREATE"] }],
      (req, user) => createAPI(req, user),
    ),
  );
}

export async function DELETE(request: Request) {
  return withErrorHandling(() =>
    checkPermission(
      request,
      [{ module: ModuleType.OPD_BILL, action: ActionType.DELETE }],
      (req, user) => deleteAPI(req, user),
    ),
  );
}
