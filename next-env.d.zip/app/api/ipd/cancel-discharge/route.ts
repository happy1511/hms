import { cancelDischargePatientAPI } from "@/controllers/ipd/ipd";
import { ActionType, ModuleType } from "@/generated/prisma/enums";
import { withErrorHandling } from "@/lib/errorHandler";
import { checkPermission } from "@/middlewares/auth/checkUserPermissions";

export async function PUT(request: Request) {
  return withErrorHandling(() =>
    checkPermission(
      request,
      [
        {
          module: ModuleType.CANCEL_DISCHARGE_PATIENT,
          action: ActionType["UPDATE"],
        },
      ],
      (req, user) => cancelDischargePatientAPI(req, user),
    ),
  );
}
